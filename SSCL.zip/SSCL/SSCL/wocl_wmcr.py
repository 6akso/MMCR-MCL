# Copyright 2019 SanghunYun, Korea University.
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import fire

import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import f1_score

import lastmodels
import lasttrain
from contrastive import SupConLoss
from load_data import load_data
from utils.utils import set_seeds, get_device, _get_device, torch_device_one
from utils import optim, configuration


# TSA
def get_tsa_thresh(schedule, global_step, num_train_steps, start, end):
    training_progress = torch.tensor(float(global_step) / float(num_train_steps))
    if schedule == 'linear_schedule':
        threshold = training_progress
    elif schedule == 'exp_schedule':
        scale = 5
        threshold = torch.exp((training_progress - 1) * scale)
    elif schedule == 'log_schedule':
        scale = 5
        threshold = 1 - torch.exp((-training_progress) * scale)
    output = threshold * (end - start) + start
    return output.to(_get_device())


def main(cfg, model_cfg):
    # Load Configuration
    cfg = configuration.params.from_json(cfg)                   # Train or Eval cfg
    model_cfg = configuration.model.from_json(model_cfg)        # BERT_cfg
    set_seeds(cfg.seed)

    # Load Data & Create Criterion
    data = load_data(cfg)
    if cfg.uda_mode:
        unsup_criterion = nn.KLDivLoss(reduction='none')
        data_iter = [data.sup_data_iter(), data.unsup_data_iter()] if cfg.mode=='train' \
            else [data.sup_data_iter(), data.unsup_data_iter(), data.eval_data_iter()]  # train_eval
    else:
        data_iter = [data.sup_data_iter()]
    sup_criterion = nn.CrossEntropyLoss(reduction='none')
    contrastive_crition = SupConLoss(1, 0.05)
    # Load Model
    model = lastmodels.Classifier(model_cfg, len(data.TaskDataset.labels))

    # Create trainer
    trainer = lasttrain.Trainer(cfg, model, data_iter, optim.optim4GPU(cfg, model), get_device())

    # Training
    def get_loss(model, sup_batch, unsup_batch, global_step):
        # logits -> prob(softmax) -> log_prob(log_softmax)
        # batch
        input_ids, segment_ids, input_mask, label_ids = sup_batch
        if unsup_batch:
            ori_input_ids, ori_segment_ids, ori_input_mask, \
            aug_input_ids, aug_segment_ids, aug_input_mask  = unsup_batch

            input_ids = torch.cat((input_ids, aug_input_ids), dim=0)
            segment_ids = torch.cat((segment_ids, aug_segment_ids), dim=0)
            input_mask = torch.cat((input_mask, aug_input_mask), dim=0)
            
        # logits
        logits2,logits,_= model(input_ids, segment_ids, input_mask)

        # sup loss
        sup_size = label_ids.shape[0]            
        sup_loss = sup_criterion(logits[:sup_size], label_ids)
        supbert_loss=sup_criterion(logits2[:sup_size], label_ids)
        uda_softmax_temp = cfg.uda_softmax_temp if cfg.uda_softmax_temp > 0 else 1.
        aug_log_probsup = F.log_softmax(logits[:sup_size] / uda_softmax_temp, dim=-1)
        aug_log_prob2sup = F.log_softmax(logits2[:sup_size] / uda_softmax_temp, dim=-1)

        unsup_losssup1 = torch.sum(unsup_criterion(aug_log_probsup,F.softmax(logits2[:sup_size], dim=-1) ), dim=-1)
        unsup_losssup2 = torch.sum(unsup_criterion(aug_log_prob2sup, F.softmax(logits[:sup_size], dim=-1)), dim=-1)
        unsup_losssup1 = torch.mean(unsup_losssup1)
        unsup_losssup2 = torch.mean(unsup_losssup2)
        # shape : train_batch_size
        if cfg.tsa:
            tsa_thresh = get_tsa_thresh(cfg.tsa, global_step, cfg.total_steps, start=1./logits.shape[-1], end=1)
            larger_than_threshold = torch.exp(-sup_loss) > tsa_thresh   # prob = exp(log_prob), prob > tsa_threshold
            # larger_than_threshold = torch.sum(  F.softmax(pred[:sup_size]) * torch.eye(num_labels)[sup_label_ids]  , dim=-1) > tsa_threshold
            loss_mask = torch.ones_like(label_ids, dtype=torch.float32) * (1 - larger_than_threshold.type(torch.float32))
            sup_loss = torch.sum(sup_loss * loss_mask, dim=-1) / torch.max(torch.sum(loss_mask, dim=-1), torch_device_one())
        else:
            sup_loss = torch.mean(sup_loss)

        if cfg.tsa:
            tsa_thresh2 = get_tsa_thresh(cfg.tsa, global_step, cfg.total_steps, start=1. / logits2.shape[-1], end=1)
            larger_than_threshold2 = torch.exp(-supbert_loss) > tsa_thresh2  # prob = exp(log_prob), prob > tsa_threshold
            # larger_than_threshold = torch.sum(  F.softmax(pred[:sup_size]) * torch.eye(num_labels)[sup_label_ids]  , dim=-1) > tsa_threshold
            loss_mask2 = torch.ones_like(label_ids, dtype=torch.float32) * (1 - larger_than_threshold2.type(torch.float32))
            supbert_loss = torch.sum(supbert_loss * loss_mask2, dim=-1) / torch.max(torch.sum(loss_mask2, dim=-1),torch_device_one())
        else:
            supbert_loss = torch.mean(supbert_loss)

        sup_loss=sup_loss+supbert_loss
                 # +0.5*unsup_losssup1+0.5*unsup_losssup2


        # unsup loss
        if unsup_batch:
            # ori
            with torch.no_grad():
                ori_logits2,ori_logits,_= model(ori_input_ids, ori_segment_ids, ori_input_mask)
                ori_prob = F.softmax(ori_logits, dim=-1)
                ori_prob2 = F.softmax(ori_logits2, dim=-1)# KLdiv target
                # ori_log_prob = F.log_softmax(ori_logits, dim=-1)

                # confidence-based masking
                if cfg.uda_confidence_thresh != -1:
                    unsup_loss_mask = torch.max(ori_prob, dim=-1)[0] > cfg.uda_confidence_thresh
                    unsup_loss_mask = unsup_loss_mask.type(torch.float32)
                else:
                    unsup_loss_mask = torch.ones(len(logits) - sup_size, dtype=torch.float32)
                unsup_loss_mask = unsup_loss_mask.to(_get_device())

                if cfg.uda_confidence_thresh != -1:
                    unsup_loss_mask2 = torch.max(ori_prob2, dim=-1)[0] > cfg.uda_confidence_thresh
                    unsup_loss_mask2 = unsup_loss_mask2.type(torch.float32)
                else:
                    unsup_loss_mask2 = torch.ones(len(logits) - sup_size, dtype=torch.float32)
                unsup_loss_mask2 = unsup_loss_mask2.to(_get_device())
                    
            # aug
            # softmax temperature controlling
            uda_softmax_temp = cfg.uda_softmax_temp if cfg.uda_softmax_temp > 0 else 1.
            aug_log_prob = F.log_softmax(logits[sup_size:] / uda_softmax_temp, dim=-1)

            aug_log_prob2 = F.log_softmax(logits2[sup_size:] / uda_softmax_temp, dim=-1)
            # KLdiv loss
            # max_probs1, targets_u1 = torch.max(ori_prob, dim=-1)
            # max_probs2, targets_u2 = torch.max(ori_prob2, dim=-1)
            # print(max_probs2,max_probs1)
            #原始数据和经过反译后的数据进行kl散度计算
            unsup_loss = torch.sum(unsup_criterion(aug_log_prob, ori_prob), dim=-1)
            unsup_loss = torch.sum(unsup_loss * unsup_loss_mask, dim=-1) / torch.max(torch.sum(unsup_loss_mask, dim=-1), torch_device_one())
            unsup_loss2 = torch.sum(unsup_criterion(aug_log_prob2, ori_prob2), dim=-1)
            unsup_loss2 = torch.sum(unsup_loss2 * unsup_loss_mask2, dim=-1) / torch.max(torch.sum(unsup_loss_mask2, dim=-1),torch_device_one())

            log_origprob = F.log_softmax(ori_logits / uda_softmax_temp, dim=-1)
            log_origprob2 = F.log_softmax(ori_logits2 / uda_softmax_temp, dim=-1)
            unsup_loss3 = torch.sum(unsup_criterion(log_origprob2, ori_prob), dim=-1)
            unsup_loss3 = torch.sum(unsup_loss3 * unsup_loss_mask, dim=-1) / torch.max(torch.sum(unsup_loss_mask, dim=-1),
                                                                        torch_device_one())
            unsup_loss4=torch.mean(torch.sum(unsup_criterion(log_origprob, ori_prob2), dim=-1))
            unsup_loss4= torch.sum(unsup_loss4 * unsup_loss_mask2, dim=-1) / torch.max(
                torch.sum(unsup_loss_mask2, dim=-1),
                torch_device_one())



            ori_prob3 = F.softmax(logits[sup_size:], dim=-1)#经过回译后的数据
            ori_prob4 = F.softmax(logits2[sup_size:], dim=-1)

            if cfg.uda_confidence_thresh != -1:
                unsup_loss_mask3 = torch.max(ori_prob3, dim=-1)[0] > cfg.uda_confidence_thresh
                unsup_loss_mask3 = unsup_loss_mask3.type(torch.float32)
            else:
                unsup_loss_mask3 = torch.ones(len(logits) - sup_size, dtype=torch.float32)
            unsup_loss_mask3 = unsup_loss_mask3.to(_get_device())

            if cfg.uda_confidence_thresh != -1:
                unsup_loss_mask4 = torch.max(ori_prob4, dim=-1)[0] > cfg.uda_confidence_thresh
                unsup_loss_mask4 = unsup_loss_mask4.type(torch.float32)
            else:
                unsup_loss_mask4 = torch.ones(len(logits) - sup_size, dtype=torch.float32)
            unsup_loss_mask4 = unsup_loss_mask4.to(_get_device())



            unsup_loss5 = torch.sum(unsup_criterion(aug_log_prob2, ori_prob3), dim=-1)
            unsup_loss5= torch.sum(unsup_loss5 * unsup_loss_mask3, dim=-1) / torch.max(
                torch.sum(unsup_loss_mask3, dim=-1),
                torch_device_one())
            unsup_loss6 =  torch.sum(unsup_criterion(aug_log_prob, ori_prob4 ), dim=-1)
            unsup_loss6 = torch.sum(unsup_loss6* unsup_loss_mask4, dim=-1) / torch.max(
                torch.sum(unsup_loss_mask4, dim=-1),
                torch_device_one())
            unsup_loss3 = unsup_loss3 + unsup_loss4+unsup_loss5+unsup_loss6
            unsup_loss=unsup_loss+unsup_loss2+0.5*unsup_loss3

            final_loss = sup_loss + cfg.uda_coeff*unsup_loss

            return final_loss, sup_loss, unsup_loss
        return sup_loss, None, None

    # evaluation
    def get_acc(model, batch):
        # input_ids, segment_ids, input_mask, label_id, sentence = batch
        input_ids, segment_ids, input_mask, label_id = batch
        logits2,logits,_= model(input_ids, segment_ids, input_mask)
        _, label_pred = logits.max(1)
        _, label_pred2 = logits2.max(1)

        result = (label_pred == label_id).float()
        accuracy = result.mean()

        result2 = (label_pred2 == label_id).float()
        accuracy2 = result2.mean()
        # output_dump.logs(sentence, label_pred, label_id)    # output dump
        f1 = f1_score(label_id.cpu().numpy(), label_pred.cpu().numpy(), average='macro')
        f2 = f1_score(label_id.cpu().numpy(), label_pred2.cpu().numpy(), average='macro')
        return accuracy, result,accuracy2, result2,f1,f2

    if cfg.mode == 'train':
        trainer.train(get_loss, None, cfg.model_file, cfg.pretrain_file)

    if cfg.mode == 'train_eval':
        trainer.train(get_loss, get_acc, cfg.model_file, cfg.pretrain_file)

    if cfg.mode == 'eval':
        results = trainer.eval(get_acc, cfg.model_file, None)
        total_accuracy = torch.cat(results).mean().item()
        print('Accuracy :' , total_accuracy)


if __name__ == '__main__':
    fire.Fire(main)
    #main('config/SSCL.json', 'config/bert_base.json')
