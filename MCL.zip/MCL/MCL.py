import torch
import torch.nn as nn
import torch.nn.functional as F


class UnSupConLoss(nn.Module):

    def __init__(self, alpha, temp):
        super().__init__()
        self.xent_loss = nn.CrossEntropyLoss()
        self.alpha = alpha
        self.temp = temp

        #anchor是bert+fnn的输出，target1是bert+rnn的输出
    def nt_xent_loss(self, anchor, target1, target2,traget3):
        device = torch.device('cuda:0')

        with torch.no_grad():
            mask = (torch.eye(anchor.size(0),dtype=torch.bool)).to(device)

        anchor_dot_target1 = torch.einsum('bd,cd->bc', anchor, target1) / self.temp
        logits_max, _ = torch.max(anchor_dot_target1, dim=1, keepdim=True)
        logits = anchor_dot_target1 - logits_max.detach()
        exp_logits = torch.exp(logits)
        logits = logits * mask

        anchor_dot_target2 = torch.einsum('bd,cd->bc', anchor, target2) / self.temp
        logits_max, _ = torch.max(anchor_dot_target2, dim=1, keepdim=True)
        logits2 = anchor_dot_target2 - logits_max.detach()
        exp_logits2 = torch.exp(logits2)
        logits2 = logits2 * mask

        anchor_dot_target3 = torch.einsum('bd,cd->bc', anchor, traget3) / self.temp
        logits_max, _ = torch.max(anchor_dot_target3, dim=1, keepdim=True)
        logits3 = anchor_dot_target3 - logits_max.detach()
        exp_logits3 = torch.exp(logits3)
        logits3 = logits3 * mask

        log_prob = (logits) - torch.log(exp_logits.sum(dim=1, keepdim=True)+1e-12)
        # log_prob = (logits+logits2+logits3) - torch.log(exp_logits.sum(dim=1, keepdim=True)+exp_logits2.sum(dim=1, keepdim=True) + exp_logits3.sum(dim=1, keepdim=True)+1e-12)
        log_prob2 = (logits2) - torch.log(exp_logits2.sum(dim=1, keepdim=True) + 1e-12)
        log_prob3 = (logits3) - torch.log(exp_logits3.sum(dim=1, keepdim=True) + 1e-12)

        # in case that mask.sum(1) is zero
        mask_sum = mask.sum(dim=1)
        mask_sum = torch.where(mask_sum == 0, torch.ones_like(mask_sum), mask_sum)
        # compute log-likelihood
        pos_logits = (mask * log_prob).sum(dim=1) / mask_sum.detach()
        pos_logits2 = (mask * log_prob2).sum(dim=1) / mask_sum.detach()
        pos_logits3 = (mask * log_prob3).sum(dim=1) / mask_sum.detach()
        loss1 = -1 * pos_logits.mean()
        loss2 = -1 * pos_logits2.mean()
        loss3 = -1 * pos_logits3.mean()
        loss=(loss1+loss2+loss3)/12
        # loss=loss3/12
        return loss

    def forward(self, anchor, target1, target2,target3):
        normed_anchor_feats = F.normalize(anchor, dim=-1)
        normed_target1_feats = F.normalize(target1, dim=-1)
        normed_target2_feats = F.normalize(target2, dim=-1)
        normed_target3_feats = F.normalize(target3, dim=-1)
        cl_loss = self.alpha * self.nt_xent_loss(normed_anchor_feats,  normed_target1_feats,  normed_target2_feats,normed_target3_feats)
        return cl_loss